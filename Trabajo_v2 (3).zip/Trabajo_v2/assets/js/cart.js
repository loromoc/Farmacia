/* Farmacia Doña Lupe · carrito + favoritos */
(() => {
  'use strict';
  const STORE = window.FARMA_STORE || {};
  const PRODUCTS = Array.isArray(STORE.products) ? STORE.products : [];
  const CART_KEY = 'farmacia_cart_v2';
  const WISH_KEY = 'farmacia_wishlist_v2';

  const parse = (key) => {
    try { const v = JSON.parse(localStorage.getItem(key)); return Array.isArray(v) ? v : []; }
    catch { return []; }
  };
  const money = v => Number(v || 0).toLocaleString('es-MX', {style:'currency', currency:'MXN', minimumFractionDigits:2, maximumFractionDigits:2});
  const esc = v => { const d=document.createElement('div'); d.textContent=String(v??''); return d.innerHTML; };
  const getCart = () => parse(CART_KEY).filter(i => Number(i.id)>0 && Number(i.cantidad)>0);
  const getWishlist = () => parse(WISH_KEY).map(Number).filter(Number.isFinite);
  const product = id => PRODUCTS.find(p => Number(p.id) === Number(id));

  function toast(message, type='ok') {
    const c=document.getElementById('toastContainer'); if(!c) return;
    const t=document.createElement('div'); t.className=`toast toast-${type}`;
    t.innerHTML=`<i class="fas ${type==='warn'?'fa-triangle-exclamation':'fa-circle-check'}"></i><span>${esc(message)}</span>`;
    c.appendChild(t);
    setTimeout(()=>{t.classList.add('toast-out');setTimeout(()=>t.remove(),280)},2800);
  }

  function saveCart(cart, message='') {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    renderCart(); if(message) toast(message);
    window.dispatchEvent(new CustomEvent('farmacia:cart'));
  }

  function saveWishlist(ids) {
    localStorage.setItem(WISH_KEY, JSON.stringify([...new Set(ids.map(Number))]));
    updateWishlistUI();
    window.dispatchEvent(new CustomEvent('farmacia:wishlist'));
  }

  function add(id) {
    const p=product(id); if(!p) return;
    if(p.requiresRx){ toast('Este producto requiere validación/receta antes de comprarse en línea.','warn'); return; }
    if(!p.shippingAllowed){ toast('Este producto no está habilitado para envío nacional.','warn'); return; }
    if(Number(p.stock)<1){ toast('Este producto está agotado.','warn'); return; }

    const cart=getCart(); const item=cart.find(i=>Number(i.id)===Number(id));
    if(item){
      if(Number(item.cantidad)>=Number(p.stock)){toast('Ya tienes el máximo disponible de este producto.','warn');return;}
      item.cantidad++; item.nombre=p.name; item.precio=Number(p.price); item.stock=Number(p.stock); item.imagen=p.image||'';
    } else {
      cart.push({id:Number(p.id),nombre:p.name,precio:Number(p.price),cantidad:1,stock:Number(p.stock),imagen:p.image||''});
    }

    const btn=document.querySelector(`[data-add-cart="${Number(id)}"]`);
    if(btn){
      const original=btn.innerHTML; btn.classList.add('added'); btn.innerHTML='<i class="fas fa-check"></i> Agregado';
      setTimeout(()=>{btn.classList.remove('added');btn.innerHTML=original},1200);
    }
    saveCart(cart, `${p.name} se agregó al carrito.`);
    const b=document.getElementById('cartBadge'); if(b){b.classList.remove('cart-bump');void b.offsetWidth;b.classList.add('cart-bump');}
  }

  function changeQty(id, delta) {
    const cart=getCart(); const item=cart.find(i=>Number(i.id)===Number(id)); const p=product(id);
    if(!item||!p)return;
    const next=Number(item.cantidad)+Number(delta);
    if(next<1){remove(id);return;}
    if(next>Number(p.stock)){toast('La cantidad supera el stock disponible.','warn');return;}
    item.cantidad=next; item.precio=Number(p.price); item.stock=Number(p.stock); saveCart(cart);
  }

  function remove(id) {
    const cart=getCart(); const item=cart.find(i=>Number(i.id)===Number(id));
    saveCart(cart.filter(i=>Number(i.id)!==Number(id)), item?`${item.nombre} se quitó del carrito.`:'');
  }

  function toggleWish(id){
    const list=getWishlist(); const n=Number(id); const idx=list.indexOf(n);
    if(idx===-1){list.push(n);toast('Agregado a favoritos.');}
    else{list.splice(idx,1);toast('Eliminado de favoritos.');}
    saveWishlist(list);
  }

  function updateWishlistUI(){
    const list=getWishlist(); const top=document.getElementById('wishlistBtn');
    if(top){const i=top.querySelector('i');if(i)i.className=list.length?'fas fa-heart':'far fa-heart';top.classList.toggle('has-items',list.length>0);}
    document.querySelectorAll('[data-wish]').forEach(btn=>{
      const active=list.includes(Number(btn.dataset.wish)); btn.classList.toggle('active',active);
      const i=btn.querySelector('i');if(i)i.className=active?'fas fa-heart':'far fa-heart';
    });
  }

  function renderCart(){
    const cart=getCart(); const body=document.getElementById('cartBody'); const footer=document.getElementById('cartFooter'); const badge=document.getElementById('cartBadge');
    const count=cart.reduce((s,i)=>s+Number(i.cantidad||0),0); if(badge)badge.textContent=String(count); if(!body)return;
    if(!cart.length){
      body.innerHTML='<div class="cart-empty"><i class="fas fa-cart-shopping"></i><p>Tu carrito está vacío.<br>Agrega productos para comenzar.</p></div>';
      if(footer)footer.hidden=true; return;
    }

    body.innerHTML=cart.map(item=>{
      const p=product(item.id); const price=p?Number(p.price):Number(item.precio); const stock=p?Number(p.stock):Number(item.stock);
      item.precio=price;item.stock=stock;item.nombre=p?.name||item.nombre;item.imagen=p?.image||item.imagen||'';
      const image=item.imagen?`<img src="${esc(item.imagen)}" alt="" class="cart-item-photo">`:'<i class="fas fa-capsules"></i>';
      return `<div class="cart-item">
        <div class="cart-item-img">${image}</div>
        <div class="cart-item-info">
          <div class="cart-item-name">${esc(item.nombre)}</div>
          <div class="cart-item-price">${money(price)} c/u</div>
          <div class="cart-item-qty">
            <button class="qty-btn" type="button" data-cart-action="minus" data-id="${Number(item.id)}">−</button>
            <span class="qty-num">${Number(item.cantidad)}</span>
            <button class="qty-btn" type="button" data-cart-action="plus" data-id="${Number(item.id)}">+</button>
          </div>
        </div>
        <div class="cart-item-side"><strong>${money(price*Number(item.cantidad))}</strong>
          <button class="cart-item-remove" type="button" data-cart-action="remove" data-id="${Number(item.id)}"><i class="fas fa-trash-can"></i></button>
        </div>
      </div>`;
    }).join('');
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    const subtotal=cart.reduce((s,i)=>s+Number(i.precio)*Number(i.cantidad),0);
    const sn=document.getElementById('cartSubtotal'),tn=document.getElementById('cartTotal');
    if(sn)sn.textContent=money(subtotal);if(tn)tn.textContent=money(subtotal);if(footer)footer.hidden=false;
  }

  function setCart(open){
    const s=document.getElementById('cartSidebar'),o=document.getElementById('cartOverlay');if(!s||!o)return;
    s.classList.toggle('open',open);o.classList.toggle('open',open);s.setAttribute('aria-hidden',open?'false':'true');document.body.classList.toggle('cart-is-open',open);
  }

  document.addEventListener('click',e=>{
    const a=e.target.closest('[data-add-cart]');if(a){add(Number(a.dataset.addCart));return;}
    const w=e.target.closest('[data-wish]');if(w){toggleWish(Number(w.dataset.wish));return;}
    const c=e.target.closest('[data-cart-action]');if(c){const id=Number(c.dataset.id);if(c.dataset.cartAction==='minus')changeQty(id,-1);if(c.dataset.cartAction==='plus')changeQty(id,1);if(c.dataset.cartAction==='remove')remove(id);}
  });
  document.getElementById('cartToggleBtn')?.addEventListener('click',()=>{const s=document.getElementById('cartSidebar');setCart(!s?.classList.contains('open'))});
  document.getElementById('cartCloseBtn')?.addEventListener('click',()=>setCart(false));
  document.getElementById('cartOverlay')?.addEventListener('click',()=>setCart(false));
  document.getElementById('checkoutBtn')?.addEventListener('click',()=>{if(!getCart().length){toast('Agrega al menos un producto.','warn');return;}location.href=STORE.checkoutUrl||'checkout.php';});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')setCart(false)});

  renderCart();updateWishlistUI();
  window.FarmaciaStoreCart={key:CART_KEY,get:getCart,clear:()=>saveCart([]),add,toggle:()=>{const s=document.getElementById('cartSidebar');setCart(!s?.classList.contains('open'))},wishlist:getWishlist,toast};
})();
