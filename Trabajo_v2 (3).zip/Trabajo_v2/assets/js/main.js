/* Farmacia Doña Lupe · navegación, búsqueda, promoción y newsletter */
(() => {
  'use strict';
  const STORE=window.FARMA_STORE||{};

  function search(){
    window.FarmaciaCatalog?.render?.();
  }

  function initSearch(){
    const input=document.getElementById('searchInput'),btn=document.getElementById('searchBtn');if(!input)return;
    let timer;input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(search,220)});
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search();document.getElementById('productos')?.scrollIntoView({behavior:'smooth'})}});
    btn?.addEventListener('click',()=>{search();document.getElementById('productos')?.scrollIntoView({behavior:'smooth'})});
  }

  function initScroll(){
    const nav=document.getElementById('navbar'),top=document.getElementById('backTop');
    const sync=()=>{nav?.classList.toggle('scrolled',scrollY>20);top?.classList.toggle('show',scrollY>420)};addEventListener('scroll',sync,{passive:true});sync();
    top?.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));
  }

  function initCountdown(){
    if(!STORE.promoEndsAt)return;const end=new Date(String(STORE.promoEndsAt).replace(' ','T')).getTime();if(!Number.isFinite(end))return;
    const d=document.getElementById('cdD'),h=document.getElementById('cdH'),m=document.getElementById('cdM'),s=document.getElementById('cdS');
    const tick=()=>{let diff=Math.max(0,end-Date.now());const days=Math.floor(diff/86400000);diff-=days*86400000;const hours=Math.floor(diff/3600000);diff-=hours*3600000;const mins=Math.floor(diff/60000);diff-=mins*60000;const secs=Math.floor(diff/1000);if(d)d.textContent=String(days).padStart(2,'0');if(h)h.textContent=String(hours).padStart(2,'0');if(m)m.textContent=String(mins).padStart(2,'0');if(s)s.textContent=String(secs).padStart(2,'0')};tick();setInterval(tick,1000);
  }

  function initNewsletter(){
    const form=document.getElementById('newsletterForm');if(!form)return;
    form.addEventListener('submit',async e=>{e.preventDefault();const input=document.getElementById('newsletterEmail');const correo=input?.value.trim()||'';if(!correo)return;const b=form.querySelector('button');if(b){b.disabled=true;b.textContent='Guardando…'}
      try{const r=await fetch('suscribir.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({correo,csrf_token:STORE.csrf||''})});const data=await r.json();if(!r.ok)throw new Error(data.error||'No fue posible guardar tu correo.');input.value='';window.FarmaciaStoreCart?.toast?.(data.mensaje||'Correo guardado correctamente.')}
      catch(err){window.FarmaciaStoreCart?.toast?.(err.message,'warn')}
      finally{if(b){b.disabled=false;b.textContent='Suscribirme'}}
    });
  }

  function initReveal(){
    if(!('IntersectionObserver'in window))return;const observer=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('reveal-visible');observer.unobserve(entry.target)}})},{threshold:.08,rootMargin:'0px 0px -30px'});
    document.querySelectorAll('.section-header,.promo-banner,.trust-strip-inner').forEach(el=>{el.classList.add('reveal');observer.observe(el)});
    const bind=()=>document.querySelectorAll('.product-card:not([data-reveal-bound])').forEach((el,i)=>{el.dataset.revealBound='1';el.classList.add('reveal');el.style.setProperty('--reveal-delay',`${Math.min(i,8)*45}ms`);observer.observe(el)});
    addEventListener('farmacia:products-rendered',bind);bind();
  }

  addEventListener('DOMContentLoaded',()=>{initSearch();initScroll();initCountdown();initNewsletter();initReveal()});
})();
