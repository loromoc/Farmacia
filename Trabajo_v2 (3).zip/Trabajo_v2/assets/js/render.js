/* Farmacia Doña Lupe · catálogo dinámico */
(() => {
  'use strict';
  const STORE=window.FARMA_STORE||{}, PRODUCTS=Array.isArray(STORE.products)?STORE.products:[], CATEGORIES=Array.isArray(STORE.categories)?STORE.categories:[];
  let activeCategory='all', currentView='grid', currentSort='default', wishlistOnly=false;
  const esc=v=>{const d=document.createElement('div');d.textContent=String(v??'');return d.innerHTML};
  const money=v=>Number(v||0).toLocaleString('es-MX',{style:'currency',currency:'MXN',minimumFractionDigits:2,maximumFractionDigits:2});
  const wishes=()=>window.FarmaciaStoreCart?.wishlist?.()||[];

  function renderCategories(){
    const grid=document.getElementById('categoriesGrid');if(!grid)return;
    grid.innerHTML=CATEGORIES.map(c=>{const raw=c.raw||'all';return `<button class="category-card ${activeCategory===raw?'active':''}" type="button" data-category="${esc(raw)}">
      <div class="category-icon">${esc(c.icon||'✚')}</div><div class="category-name">${esc(c.name)}</div>
      <div class="category-count">${Number(c.count||0)} producto${Number(c.count||0)===1?'':'s'}</div></button>`}).join('');
  }

  function filtered(){
    let list=activeCategory==='all'?[...PRODUCTS]:PRODUCTS.filter(p=>p.category===activeCategory);
    const q=(document.getElementById('searchInput')?.value||'').trim().toLocaleLowerCase('es-MX');
    if(q) list=list.filter(p=>[p.name,p.desc,p.category,p.activeIngredient,p.presentation].some(v=>String(v||'').toLocaleLowerCase('es-MX').includes(q)));
    if(wishlistOnly){const ids=wishes();list=list.filter(p=>ids.includes(Number(p.id)))}
    if(currentSort==='price-asc')list.sort((a,b)=>Number(a.price)-Number(b.price));
    else if(currentSort==='price-desc')list.sort((a,b)=>Number(b.price)-Number(a.price));
    else if(currentSort==='name')list.sort((a,b)=>String(a.name).localeCompare(String(b.name),'es'));
    else list.sort((a,b)=>Number(b.sold||0)-Number(a.sold||0)||Number(b.id)-Number(a.id));
    return list;
  }

  function card(p){
    const inWish=wishes().includes(Number(p.id));
    const image=p.image?`<img class="product-img" src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">`:'<div class="product-emoji-placeholder"><i class="fas fa-capsules"></i></div>';
    const bclass={offer:'badge-offer',rx:'badge-rx',hot:'badge-hot'}[p.badge]||'';
    let action='';
    if(Number(p.stock)<=0)action='<button class="btn-add-cart" type="button" disabled>Agotado</button>';
    else if(p.requiresRx)action='<button class="btn-add-cart btn-rx" type="button" disabled>Requiere receta</button>';
    else if(!p.shippingAllowed)action='<button class="btn-add-cart btn-rx" type="button" disabled>Sin envío</button>';
    else action=`<button class="btn-add-cart" type="button" data-add-cart="${Number(p.id)}"><i class="fas fa-cart-plus"></i> Agregar</button>`;
    const meta=[p.activeIngredient,p.presentation].filter(Boolean).map(esc).join(' · ');
    return `<article class="product-card" id="pc-${Number(p.id)}">
      ${p.badge?`<div class="product-badge ${bclass}">${esc(p.badgeText||'')}</div>`:''}
      <button class="product-wish ${inWish?'active':''}" type="button" data-wish="${Number(p.id)}" aria-label="Favoritos"><i class="${inWish?'fas':'far'} fa-heart"></i></button>
      <div class="product-img-wrap">${image}</div>
      <div class="product-body">
        <div class="product-category-tag">${esc(p.category)}</div><h3 class="product-name">${esc(p.name)}</h3>
        ${meta?`<div class="product-meta-line">${meta}</div>`:''}<p class="product-desc">${esc(p.desc)}</p>
        ${p.promoName?`<div class="product-promo-name"><i class="fas fa-tag"></i> ${esc(p.promoName)}</div>`:''}
        <div class="product-stock-row"><span class="${Number(p.stock)>0?'stock-ok':'stock-out'}">${Number(p.stock)>0?`<i class="fas fa-circle-check"></i> ${Number(p.stock)} disponibles`:'Agotado'}</span>${p.requiresRx?'<span class="rx-note">Rx</span>':''}</div>
        <div class="product-price-row"><div class="product-prices"><span class="product-price">${money(p.price)}</span>${p.oldPrice?`<span class="product-price-old">${money(p.oldPrice)}</span>`:''}</div>${action}</div>
      </div></article>`;
  }

  function render(){
    const list=filtered(),count=document.getElementById('productCount'),grid=document.getElementById('productsGrid');
    if(count)count.textContent=wishlistOnly?`Favoritos: ${list.length}`:`Mostrando ${list.length} producto${list.length===1?'':'s'}`;
    if(!grid)return;grid.classList.toggle('list-view',currentView==='list');
    if(!list.length){grid.innerHTML='<div class="catalog-empty"><i class="fas fa-magnifying-glass"></i><strong>No encontramos productos</strong><p>Cambia la búsqueda, la categoría o el filtro de favoritos.</p></div>';return}
    grid.innerHTML=list.map(card).join('');window.dispatchEvent(new CustomEvent('farmacia:products-rendered'));
  }

  function setCategory(c){activeCategory=c||'all';wishlistOnly=false;renderCategories();render()}
  function setView(v){currentView=v==='list'?'list':'grid';document.getElementById('gridViewBtn')?.classList.toggle('active',currentView==='grid');document.getElementById('listViewBtn')?.classList.toggle('active',currentView==='list');render()}

  function renderFeatured(){
    const list=(STORE.featured||[]).map(id=>PRODUCTS.find(p=>Number(p.id)===Number(id))).filter(Boolean);if(!list.length)return;
    const first=list[0],hero=document.getElementById('featuredHero'),best=document.getElementById('bestsellersList');
    if(hero){const visual=first.image?`<img src="${esc(first.image)}" alt="${esc(first.name)}">`:'<i class="fas fa-capsules"></i>';
      hero.innerHTML=`<div class="featured-hero-card"><div><div class="featured-hero-badge">${first.sold>0?'Más solicitado':'Producto destacado'}</div><div class="featured-product-visual">${visual}</div><div class="featured-hero-name">${esc(first.name)}</div></div><div><div class="featured-hero-price">${money(first.price)}</div>${!first.requiresRx&&first.shippingAllowed&&Number(first.stock)>0?`<button class="featured-hero-btn" type="button" data-add-cart="${Number(first.id)}"><i class="fas fa-cart-plus"></i> Añadir al carrito</button>`:'<span class="featured-restricted">Consulta disponibilidad y requisitos</span>'}</div></div>`}
    if(best)best.innerHTML=list.slice(1).map((p,i)=>`<div class="bestseller-card"><div class="bestseller-rank ${i<2?'top':''}">0${i+2}</div><div class="bestseller-img">${p.image?`<img src="${esc(p.image)}" alt="">`:'<i class="fas fa-capsules"></i>'}</div><div class="bestseller-info"><div class="bestseller-name">${esc(p.name)}</div><div class="bestseller-cat">${esc(p.category)}</div></div><div><div class="bestseller-price">${money(p.price)}</div><div class="bestseller-stock">${Number(p.stock)>0?`✓ ${Number(p.stock)} disponibles`:'Agotado'}</div></div></div>`).join('');
  }

  document.addEventListener('click',e=>{const c=e.target.closest('[data-category]');if(c){setCategory(c.dataset.category);document.getElementById('productos')?.scrollIntoView({behavior:'smooth',block:'start'});return}const v=e.target.closest('[data-view]');if(v)setView(v.dataset.view)});
  document.getElementById('sortSelect')?.addEventListener('change',e=>{currentSort=e.target.value;render()});
  document.getElementById('wishlistBtn')?.addEventListener('click',()=>{wishlistOnly=!wishlistOnly;activeCategory='all';renderCategories();render();document.getElementById('productos')?.scrollIntoView({behavior:'smooth',block:'start'});if(!wishes().length)window.FarmaciaStoreCart?.toast?.('Tu lista de favoritos está vacía.','warn')});
  window.addEventListener('farmacia:wishlist',render);
  renderCategories();render();renderFeatured();
  window.FarmaciaCatalog={render,filterByCategory:setCategory,setView};
})();
